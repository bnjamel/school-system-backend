# school-system-backend

## To get started run the following code
```
git clone https://github.com/bnjamel/school-system-backend.git
cd school-system-backend
npm install
npm start
```
